package domain;

import request.BuyRequest;
import request.GetNrLocuriRequest;
import response.BuyResponse;
import response.GetNrLocuriResponse;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Client2 {

    public static void showMenu(){
        System.out.println("1.Print available tickets");
        System.out.println("2.Buy ticket");
        System.out.println("3.Exit");
    }

    public static void handlePrintResponse(GetNrLocuriResponse response){
        for(NrLocuri s : response.getResponse()){
            System.out.println(s);
        }
    }

    public static void handleBuyResponse(BuyResponse response){
        if(response.getOkResponse()){
            System.out.println("Success!");
        }
        else{
            System.out.println("Internal error. Please retry");
        }
    }

    public static BuyRequest Buy(){
        Scanner in = new Scanner(System.in);

        System.out.println("clientName: ");
        String name = in.next();

        System.out.println("ticketId: ");
        Integer id = in.nextInt();

        System.out.println("quantity: ");
        Integer quantity = in.nextInt();

        return new BuyRequest(name, id, quantity);
    }

    public static void main(String[] args) throws Exception{
        Socket socket = new Socket("127.0.0.1", 4444);
        ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
        ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());

        Scanner scanner = new Scanner(System.in);

        String s = "";
        while(!s.equals("3")){
            showMenu();
            s = scanner.next();

            if(s.equals("1")){
                // send get nrLocuri request
                outputStream.writeObject(new GetNrLocuriRequest());
                // handle getNrLocuri response
                handlePrintResponse((GetNrLocuriResponse)inputStream.readObject());
            }
            else if (s.equals("2")){
                // send buy request
                outputStream.writeObject(Buy());
                // handle buy response
                handleBuyResponse((BuyResponse)inputStream.readObject());
            }
            else if (!s.equals("3")){
                System.out.println("Not a valid option!! Please type a valid one this time :) ");
            }

            outputStream.reset();
        }

        inputStream.close();
        outputStream.close();
        socket.close();

    }
}
