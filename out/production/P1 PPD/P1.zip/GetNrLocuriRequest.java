package request;

import java.io.Serializable;

public class GetNrLocuriRequest implements Serializable{
    public GetNrLocuriRequest() {
    }
}
