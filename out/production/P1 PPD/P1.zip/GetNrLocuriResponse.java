package response;

import domain.NrLocuri;

import java.io.Serializable;
import java.util.List;

public class GetNrLocuriResponse implements Serializable {
    private List<NrLocuri> response;

    public GetNrLocuriResponse(List<NrLocuri> response) {
        this.response = response;
    }

    public List<NrLocuri> getResponse() {
        return response;
    }

    public void setResponse(List<NrLocuri> response) {
        this.response = response;
    }
}
