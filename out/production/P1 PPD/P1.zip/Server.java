package startServer;

import controller.TicketController;
import domain.NrLocuri;
import request.BuyRequest;
import request.GetNrLocuriRequest;
import response.BuyResponse;
import response.GetNrLocuriResponse;
import services.CheckerClass;
import services.TicketService;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Server {
    private ServerSocket serverSocket;
    private ExecutorService executorService;
    private TicketController ticketController;
    public long serverStartTime;

    public void start(int port, TicketController ticketController) throws IOException {
        serverSocket = new ServerSocket(port);
        this.ticketController = ticketController;
        serverStartTime = System.currentTimeMillis()/1000L;
        executorService = Executors.newFixedThreadPool(10);

        while (true)
            if(serverStartTime + 10 == System.currentTimeMillis())
                serverSocket.close();
            else
                executorService.submit(new EchoClientHandler(serverSocket.accept(), ticketController));
    }

    public void stop() throws IOException {
        executorService.shutdownNow();
        this.ticketController.Stop();
        serverSocket.close();
    }

    public static void main(String[] args) throws Exception{

        TicketService p = new TicketService();
        TicketController c = new TicketController(p);
        Server s = new Server();

        // Start checker
        CheckerClass checker = new CheckerClass(c);
        checker.start();

        s.start(4444, c);


        checker.Stop();
        checker.join();
    }

    private static class EchoClientHandler extends Thread {
        private Socket clientSocket;
        private ObjectOutputStream outputStream;
        private ObjectInputStream inputStream;
        private TicketController ticketController;

        EchoClientHandler(Socket socket, TicketController ticketController) {
            this.clientSocket = socket;
            this.ticketController = ticketController;
        }

        public void run() {
            try {
                outputStream = new ObjectOutputStream(clientSocket.getOutputStream());
                inputStream = new ObjectInputStream(clientSocket.getInputStream());

                while(true){
                    Object request = inputStream.readObject();
                    if (request instanceof GetNrLocuriRequest){
                        outputStream.writeObject(HandleGetNrLocuri());
                    }
                    else if (request instanceof BuyRequest){
                        outputStream.writeObject(HandleBuyRequest((BuyRequest)request));
                    }
                    else break;

                    outputStream.reset();
                }

                inputStream.close();
                outputStream.close();
                this.clientSocket.close();

            } catch (Exception e) {
                throw new RuntimeException("Unexpected exception!!");
            }
        }

        GetNrLocuriResponse HandleGetNrLocuri() throws ExecutionException, InterruptedException {
            Future<List<NrLocuri>> nrLocuri = ticketController.GetNrLocuri();
            return new GetNrLocuriResponse(nrLocuri.get());
        }

        BuyResponse HandleBuyRequest(BuyRequest request) throws ExecutionException, InterruptedException {
            Future<Boolean> buy = ticketController.Buy(request.getClientName(), request.getTicketId(), request.getQuantity());
            return new BuyResponse(buy.get());
        }

    }
}
