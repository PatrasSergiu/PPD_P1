package startServer;

import domain.NrLocuri;
import request.BuyRequest;
import request.GetNrLocuriRequest;
import response.GetNrLocuriResponse;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
import java.util.Random;

public class TestClient {

    private static List<NrLocuri> spectacole;
    private static Random random = new Random();

    private static BuyRequest CreateBuyRequest(){
        Integer id = random.nextInt(spectacole.size());
        Integer nr_locuri = random.nextInt(5) + 1;

        return new BuyRequest("TestClient",id, nr_locuri);
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Socket socket = new Socket("127.0.0.1", 4444);
        ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
        ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());

        outputStream.writeObject(new GetNrLocuriRequest());

        spectacole = ((GetNrLocuriResponse)inputStream.readObject()).getResponse();
        // create buy requests until server throws exception
        while(true){
            try {
                outputStream.writeObject(CreateBuyRequest());
                inputStream.readObject();   // check result of buy request
                Thread.sleep(2000);
            }catch (Exception ignored){
                break;
            }
        }
        inputStream.close();
        outputStream.close();
        socket.close();
    }
}
