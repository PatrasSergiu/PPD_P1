package services;

import domain.Bill;
import domain.Ticket;
import domain.NrLocuri;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class TicketService {
    private ReentrantReadWriteLock lock;
    private HashMap<Integer, NrLocuri> nrLocuri;
    private ConcurrentLinkedQueue<Bill> bills;
    private DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

    private Double lastCheckSold;
    private Double currentSold;

    public TicketService(){
        lock = new ReentrantReadWriteLock();
        nrLocuri = new HashMap<>();
        bills = new ConcurrentLinkedQueue<>();
        lastCheckSold = 0.0;
        currentSold = 0.0;

        LoadTickets();
    }

    public void Buy(String clientName, Integer ticketId, Integer quantity) {
        lock.readLock().lock();

        // Ticket not found
        if (!nrLocuri.containsKey(ticketId)){
            lock.readLock().unlock();
            throw new RuntimeException("Ticket: " + ticketId + "doesn't exist!");
        }
        // lock nrLocuri for the ticket with the given ticket id
        synchronized (nrLocuri.get(ticketId)) {
            NrLocuri s = nrLocuri.get(ticketId);
            if (s.getQuantity() < quantity){
                lock.readLock().unlock();
                throw new RuntimeException("Quantity too small: " + ticketId);
            }
            // Update quantity
            s.setQuantity(s.getQuantity() - quantity);

            // Register new bill
            Ticket p = nrLocuri.get(ticketId).getTicket();
            Bill bill = new Bill(p.getId(), quantity, quantity * p.getPrice(), clientName);
            bills.add(bill);

            // Update current sold
            currentSold += (quantity * p.getPrice());
        }

        lock.readLock().unlock();
    }

    public void Check(){
        lock.writeLock().lock();

        try(FileWriter fw = new FileWriter("C:\\Users\\edi\\IdeaProjects\\PPD\\ProiectClientServer\\src\\main\\resources\\log.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw))
        {
            out.write("[ STARTED CHECKING -  " + dateFormat.format(new Date()) + " ]\n\n");

            Double totalBillsValue = CalculateTotalBills();

            out.write(" Last Sold - " + lastCheckSold + "\n");
            out.write(" Current Sold - " + currentSold + "\n");
            out.write(" Bills Total - " + totalBillsValue + "\n");

            Double rt = totalBillsValue + lastCheckSold;

            if( Math.abs(rt - currentSold)  > 0.00001) {
                out.write("ERROR Corrupted sold!");
            }
            else {
                out.write(" BILLS:\n\n");
                // Dump bills
                for (Bill b : bills){
                    out.write(b.toString() + "\n");
                }
            }
            out.write("\n[ FINISHED CHECKING -  " + dateFormat.format(new Date()) + " ]\n\n");

            // Free bills
            lastCheckSold = currentSold;
            bills.clear();

        } catch (IOException e) {
            e.printStackTrace();
        }

        lock.writeLock().unlock();
    }

    public List<NrLocuri> GetNrLocuri(){
        lock.readLock().lock();

        ArrayList<NrLocuri> availableTickets = new ArrayList<>();
        for(Integer id : nrLocuri.keySet()){
            synchronized (nrLocuri.get(id)) {
                availableTickets.add(nrLocuri.get(id));
            }
        }

        lock.readLock().unlock();
        return availableTickets;
    }

    private Double CalculateTotalBills(){
        Double total = 0.0;
        for(Bill b : bills) {
            total += b.getTotal();
        }

        return total;
    }

    private void LoadTickets(){
        try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\edi\\IdeaProjects\\PPD\\ProiectClientServer\\src\\main\\resources\\tickets.txt"))) {
            String line;
            while (null != (line = br.readLine())) {
                String[] parts = line.split(",");

                Ticket p = new Ticket(parts[1],parts[2],Double.parseDouble(parts[3]), Integer.parseInt(parts[0]));
                NrLocuri s = new NrLocuri(p, Integer.parseInt(parts[4]));
                nrLocuri.put(p.getId(), s);
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
}
